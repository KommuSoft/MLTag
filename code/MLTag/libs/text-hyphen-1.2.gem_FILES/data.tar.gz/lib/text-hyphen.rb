# -*- ruby encoding: utf-8 -*-
require 'text/hyphen'

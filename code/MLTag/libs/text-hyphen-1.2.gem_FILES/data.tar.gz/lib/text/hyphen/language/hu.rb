require 'text/hyphen/language/hu1'

# -*- encoding: utf-8 -*-

Text::Hyphen.require_real_hyphenation_file(__FILE__)
Text::Hyphen::Language.aliases_for "MN" => "MON"

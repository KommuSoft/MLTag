require 'text/hyphen/language/no1'
